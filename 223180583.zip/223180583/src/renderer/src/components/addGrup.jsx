import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function AddGrup() {
  const [judul, setJudul] = useState('')
  const navigate = useNavigate()
  const username = localStorage.getItem('username')

  const handleSubmit = async () => {
    if (!judul.trim()) {
      alert('Judul grup tidak boleh kosong')
      return
    }

    try {
      const result = await window.api.addGroupFolder({ judul, username })
      if (result.success) {
        alert('Grup folder berhasil dibuat!')
        navigate('/grup')
      } else {
        alert('Gagal membuat grup folder.')
      }
    } catch (error) {
      console.error('Error:', error)
      alert('Terjadi kesalahan.')
    }
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>Buat Grup Folder Baru</h2>
      <input
        type="text"
        placeholder="Judul Grup"
        value={judul}
        onChange={(e) => setJudul(e.target.value)}
        style={{ padding: 8, width: 300 }}
      />
      <br /><br />
      <button
        onClick={handleSubmit}
        style={{ marginRight: 10, padding: '5px 10px' }}
      >
        Submit
      </button>
      <button
        onClick={() => navigate('/grup')}
        style={{ padding: '5px 10px' }}
      >
        Back
      </button>
    </div>
  )
}