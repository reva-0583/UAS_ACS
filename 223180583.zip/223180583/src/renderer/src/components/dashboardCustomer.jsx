import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
const DashboardCustomer = () => {
  const [notes, setNotes] = useState([]);
  const [titles, setTitles] = useState([]);
  useEffect(() => {
    window.api.getPublicNotes().then(setNotes);
    window.api.getPublicTitles().then(setTitles);
  }, []);
  const previewText = (text) => {
    let result = '';
    let count = 0;
    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      if (/[a-zA-Z0-9]/.test(char)) count++;
      result += char;
      if (count >= 12) {
        result += '...';
        break;
      }
    }
    return result;
  };
  return (
    <div style={{ display: 'flex', fontFamily: 'Arial, sans-serif' }}>
      <nav style={{width: 208, backgroundColor: 'rgb(251, 251, 251)', padding: 20, height: '100vh', position: 'fixed', top: 0, left: 0, borderRight: '2px solid rgba(128, 128, 128, 0.3)'}}>
        <h4>Public Notes</h4>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {titles.map((note, i) => (
            <li key={i}>
              <Link to={`/detail/${note.judul}`} style={{ textDecoration: 'none', color: 'black' }}>{note.judul}</Link>
            </li>
          ))}
        </ul>
        <h4>My Notes</h4>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li><a href="viewFolder.php" style={{ textDecoration: 'none', color: 'black' }}>Folder Pribadi</a></li>
          <li><a href="#" style={{ textDecoration: 'none', color: 'black' }}>Catatan Kuliah</a></li>
          <li><a href="#" style={{ textDecoration: 'none', color: 'black' }}>Proyek Kerja</a></li>
          <li><a href="#" style={{ textDecoration: 'none', color: 'black' }}>Jurnal Harian</a></li>
        </ul>
      </nav>
      <div style={{ flexGrow: 1, marginLeft: 250 }}>
        <header style={{position: 'fixed', top: 0, left: 250, right: 0, padding: 10, backgroundColor: 'rgb(242, 242, 242)', borderBottom: '1px solid #ddd', display: 'flex', justifyContent: 'space-between', alignItems: 'center', zIndex: 1000}}>
          <h1 style={{ margin: 0 }}>Catat-Catat</h1>
          <div>
            <button style={btnStyle}><Link to="/dashboard" style={linkStyle}>Home</Link></button>
            <button style={btnStyle}><Link to="/grup" style={linkStyle}>My Group</Link></button>
            <button style={btnStyle}><Link to="/view-folder" style={linkStyle}>My Folder</Link></button>
            <button style={btnStyle}><Link to="/addFolder" style={linkStyle}>Add Folder</Link></button>
            <button style={{ ...btnStyle, marginRight: 15 }}><Link to="/logout" style={linkStyle}>Logout</Link></button>
          </div>
        </header>
        <main style={{ padding: 20, marginTop: 60 }}>
          <h2>Public Notes</h2>
          <div style={{display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10, marginTop: 20, textAlign: 'left'}}>
            {notes.map((note) => (
              <div key={note.id_catatan} style={{ border: '1px solid #ddd', padding: 10, background: 'white' }}>
                <h5 style={{ margin: 0, fontSize: 16, marginBottom: 10 }}>{note.judul}</h5>
                <span>{previewText(note.catatan)}</span><br />
                <Link to={`/detail/${encodeURIComponent(note.judul)}`} style={{display: 'inline-block', marginTop: 10, padding: 5, background: 'rgb(251, 251, 251)', color: 'black', textDecoration: 'none', border: '0.5px solid rgb(242, 242, 242)'}}>View Detail</Link>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
};
const btnStyle = {marginLeft: 5, padding: '5px 10px', border: '1px solid #ccc', background: 'white', cursor: 'pointer',};
const linkStyle = {textDecoration: 'none', color: 'black'};
export default DashboardCustomer;