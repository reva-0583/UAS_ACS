import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function AdminGrupPage() {
  const [groups, setGroups] = useState([]);
  const [editingGroup, setEditingGroup] = useState(null);
  const [editForm, setEditForm] = useState({ id_group_folder: '', judul: '', owner_username: '' });
  const navigate = useNavigate();

  useEffect(() => {
    fetchGroups();
  }, []);

  async function fetchGroups() {
    try {
      const data = await window.api.getAllGroupFolders();
      setGroups(data);
    } catch (error) {
      console.error('Gagal fetch group folders:', error);
    }
  }

  function handleEditClick(group) {
    setEditingGroup(group.id_group_folder);
    setEditForm({ ...group });
  }

  function handleInputChange(e) {
    const { name, value } = e.target;
    setEditForm(prev => ({ ...prev, [name]: value }));
  }

  async function handleSaveEdit() {
    try {
      const result = await window.api.updateGroupFolder(editForm);
      if (result.success) {
        alert('Group folder berhasil diupdate.');
        setEditingGroup(null);
        setEditForm({ id_group_folder: '', judul: '', owner_username: '' });
        fetchGroups();
      } else {
        alert('Gagal update group folder: ' + result.error);
      }
    } catch (error) {
      alert('Terjadi error saat update group folder.');
    }
  }

  async function handleDelete(id_group_folder) {
    const confirmDelete = window.confirm(`Yakin ingin menghapus grup folder dengan ID ${id_group_folder}?`);
    if (confirmDelete) {
      try {
        const result = await window.api.deleteGroupFolder(id_group_folder);
        if (result.success) {
          alert('Group folder berhasil dihapus.');
          fetchGroups();
        } else {
          alert('Gagal menghapus group folder: ' + result.error);
        }
      } catch (error) {
        alert('Terjadi error saat menghapus group folder.');
      }
    }
  }

  function handleCancelEdit() {
    setEditingGroup(null);
    setEditForm({ id_group_folder: '', judul: '', owner_username: '' });
  }

  return (
    <div style={{ display: 'flex' }}>
      <nav style={{ width: '200px', padding: '20px', borderRight: '1px solid #ddd' }}>
        <h4>Admin Menu</h4>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li><button onClick={() => navigate('/admin')}>Home</button></li>
          <li><button onClick={() => navigate('/')}>Logout</button></li>
        </ul>
      </nav>
      <div style={{ flexGrow: 1, padding: '20px' }}>
        <header style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
          <h1>Data Grup Folder</h1>
        </header>
        {groups.length === 0 ? (
          <p>Belum ada grup folder tersedia.</p>
        ) : (
          <>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={headerStyle}>No</th>
                  <th style={headerStyle}>ID Grup</th>
                  <th style={headerStyle}>Judul</th>
                  <th style={headerStyle}>Owner Username</th>
                  <th style={headerStyle}>Aksi</th>
                </tr>
              </thead>
              <tbody>
                {groups.map((group, index) => (
                  <tr key={group.id_group_folder}>
                    <td style={cellStyle}>{index + 1}</td>
                    <td style={cellStyle}>{group.id_group_folder}</td>
                    <td style={cellStyle}>{group.judul}</td>
                    <td style={cellStyle}>{group.owner_username}</td>
                    <td style={cellStyle}>
                      <button style={{ marginRight: 8 }} onClick={() => handleEditClick(group)}>Edit</button>
                      <button style={{ marginRight: 8 }} onClick={() => navigate('/admin-grup-detail', { state: group })}>View Details</button>
                      <button style={{ backgroundColor: '#e74c3c', color: '#fff', border: 'none', padding: '5px 10px', cursor: 'pointer' }} onClick={() => handleDelete(group.id_group_folder)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {editingGroup && (
              <div style={{ marginTop: '20px', border: '1px solid #ccc', padding: '15px', borderRadius: '5px', backgroundColor: '#f9f9f9' }}>
                <h3>Edit Grup Folder</h3>
                <div style={{ marginBottom: '10px' }}>
                  <label>Judul:</label><br />
                  <input type="text" name="judul" value={editForm.judul} onChange={handleInputChange} style={{ width: '100%' }} />
                </div>
                <div style={{ marginBottom: '10px' }}>
                  <label>Owner Username:</label><br />
                  <input type="text" name="owner_username" value={editForm.owner_username} readOnly style={{ width: '100%', backgroundColor: '#eee', cursor: 'not-allowed' }} />
                </div>
                <div>
                  <button onClick={handleSaveEdit} style={{ marginRight: '10px' }}>Save Edit</button>
                  <button onClick={handleCancelEdit}>Cancel</button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
const headerStyle = { border: '1px solid #ccc', padding: '8px', textAlign: 'center', backgroundColor: '#f0f0f0' };
const cellStyle = { border: '1px solid #ccc', padding: '8px', textAlign: 'center' };