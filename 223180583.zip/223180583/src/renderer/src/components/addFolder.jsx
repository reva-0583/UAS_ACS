import React, { useEffect, useState } from 'react';
function AddFolderPage() {
  const [judul, setJudul] = useState('');
  const [folders, setFolders] = useState([]);
  const username = 'admin';
  useEffect(() => {
    async function fetchFolders() {
      try {
        const data = await window.api.getFoldersByUsername(username);
        setFolders(data);
      } catch (error) {
        console.error('Error fetching folders:', error);
      }
    }
    fetchFolders();
  }, [username]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!judul.trim()) {
      alert('Judul folder tidak boleh kosong!');
      return;
    }
    const existing = folders.find((folder) => folder.judul === judul.trim());
    if (existing) {
      alert('Folder dengan judul yang sama sudah ada.');
      return;
    }
    try {
      const result = await window.api.addFolder(judul.trim(), username);
      if (result.success) {
        alert('Folder berhasil ditambahkan!');
        const updatedFolders = await window.api.getFoldersByUsername(username);
        setFolders(updatedFolders);
        setJudul('');
      } else {
        alert('Gagal menambahkan folder: ' + result.error);
      }
    } catch (error) {
      console.error('Error adding folder:', error);
      alert('Terjadi kesalahan saat menambahkan folder.');
    }
  };
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <button
        onClick={() => window.location.href = '/dashboard'}
        style={{
          padding: '5px 10px',
          border: '1px solid #ccc',
          background: 'white',
          cursor: 'pointer'
        }}
      >
        Back
      </button>
      <br />
      <h2>Add Folder</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="judul">Nama Folder:</label>
        <br />
        <input
          type="text"
          id="judul"
          value={judul}
          onChange={(e) => setJudul(e.target.value)}
          required
        />
        <br /><br />
        <button
          type="submit"
          style={{
            padding: '5px 10px',
            border: '1px solid #ccc',
            background: 'white',
            cursor: 'pointer'
          }}
        >
          Create
        </button>
      </form>
      <br />
      <h3>Daftar Folder:</h3>
      <ul>
        {folders.map((folder) => (
          <li key={folder.judul}>{folder.judul}</li>
        ))}
      </ul>
    </div>
  );
}
export default AddFolderPage;