import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
export default function AdminGrupNotePage() {
  const [notes, setNotes] = useState([]);
  const [editingNote, setEditingNote] = useState(null);
  const [editForm, setEditForm] = useState({
    id_group_note: '',
    id_group_folder: '',
    username: '',
    judul: '',
    catatan: ''
  });
  const navigate = useNavigate();
  useEffect(() => {
    fetchNotes();
  }, []);
  async function fetchNotes() {
    try {
      const data = await window.api.getAllGroupNotes();
      setNotes(data);
    } catch (error) {
      console.error('Gagal fetch group notes:', error);
    }
  }
  function handleEditClick(note) {
    setEditingNote(note.id_group_note);
    setEditForm({ ...note });
  }
  function handleInputChange(e) {
    const { name, value } = e.target;
    setEditForm(prev => ({ ...prev, [name]: value }));
  }
  async function handleSaveEdit() {
    try {
      const result = await window.api.editGroupNote(editForm);
      if (result.success) {
        alert('Catatan grup berhasil diupdate.');
        setEditingNote(null);
        fetchNotes();
      } else {
        alert('Gagal update: ' + result.error);
      }
    } catch {
      alert('Terjadi error saat update.');
    }
  }
  async function handleDelete(id_group_note) {
    const confirmDelete = window.confirm(`Yakin ingin menghapus catatan grup dengan ID ${id_group_note}?`);
    if (confirmDelete) {
      try {
        const result = await window.api.removeGroupNote(id_group_note);
        if (result.success) {
          alert('Berhasil dihapus.');
          fetchNotes();
        } else {
          alert('Gagal menghapus: ' + result.error);
        }
      } catch {
        alert('Terjadi error saat menghapus.');
      }
    }
  }
  function handleCancelEdit() {
    setEditingNote(null);
    setEditForm({
      id_group_note: '',
      id_group_folder: '',
      username: '',
      judul: '',
      catatan: ''
    });
  }
  return (
    <div style={{ display: 'flex' }}>
      <nav style={{ width: '200px', padding: '20px', borderRight: '1px solid #ddd' }}>
        <h4>Admin Menu</h4>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li><button onClick={() => navigate('/admin')}>Home</button></li>
          <li><button onClick={() => navigate('/')}>Logout</button></li>
        </ul>
      </nav>
      <div style={{ flexGrow: 1, padding: '20px' }}>
        <header style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
          <h1>Data Catatan Grup</h1>
        </header>
        {notes.length === 0 ? (
          <p>Belum ada catatan grup tersedia.</p>
        ) : (
          <>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={headerStyle}>No</th>
                  <th style={headerStyle}>ID</th>
                  <th style={headerStyle}>ID Folder</th>
                  <th style={headerStyle}>Username</th>
                  <th style={headerStyle}>Judul</th>
                  <th style={headerStyle}>Catatan</th>
                  <th style={headerStyle}>Tanggal</th>
                  <th style={headerStyle}>Aksi</th>
                </tr>
              </thead>
              <tbody>
                {notes.map((note, index) => (
                  <tr key={note.id_group_note}>
                    <td style={cellStyle}>{index + 1}</td>
                    <td style={cellStyle}>{note.id_group_note}</td>
                    <td style={cellStyle}>{note.id_group_folder}</td>
                    <td style={cellStyle}>{note.username}</td>
                    <td style={cellStyle}>{note.judul}</td>
                    <td style={cellStyle}>{note.catatan}</td>
                    <td style={cellStyle}>{new Date(note.tanggal_ditambahkan).toLocaleString()}</td>
                    <td style={cellStyle}>
                      <button style={{ marginRight: 8 }} onClick={() => handleEditClick(note)}>Edit</button>
                      <button onClick={() => navigate('/admin-group-note-detail', { state: note })} style={{ marginRight: 8 }}>View Detail</button>
                      <button style={{ backgroundColor: '#e74c3c', color: '#fff', border: 'none', padding: '5px 10px', cursor: 'pointer' }} onClick={() => handleDelete(note.id_group_note)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {editingNote && (
              <div style={{ marginTop: '20px', border: '1px solid #ccc', padding: '15px', borderRadius: '5px', backgroundColor: '#f9f9f9' }}>
                <h3>Edit Catatan Grup</h3>
                <div style={{ marginBottom: '10px' }}>
                  <label>Judul:</label><br />
                  <input type="text" name="judul" value={editForm.judul} onChange={handleInputChange} style={{ width: '100%' }} />
                </div>
                <div style={{ marginBottom: '10px' }}>
                  <label>Catatan:</label><br />
                  <textarea name="catatan" value={editForm.catatan} onChange={handleInputChange} style={{ width: '100%' }} rows={4}></textarea>
                </div>
                <div style={{ marginBottom: '10px' }}>
                  <label>Username:</label><br />
                  <input type="text" name="username" value={editForm.username} readOnly style={{ width: '100%', backgroundColor: '#eee', cursor: 'not-allowed' }} />
                </div>
                <div style={{ marginBottom: '10px' }}>
                  <label>ID Group Folder:</label><br />
                  <input type="text" name="id_group_folder" value={editForm.id_group_folder} readOnly style={{ width: '100%', backgroundColor: '#eee', cursor: 'not-allowed' }} />
                </div>
                <div>
                  <button onClick={handleSaveEdit} style={{ marginRight: '10px' }}>Save Edit</button>
                  <button onClick={handleCancelEdit}>Cancel</button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
const headerStyle = { border: '1px solid #ccc', padding: '8px', textAlign: 'center', backgroundColor: '#f0f0f0' };
const cellStyle = { border: '1px solid #ccc', padding: '8px', textAlign: 'center' };