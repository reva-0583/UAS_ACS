import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function AdminPage() {
  const [users, setUsers] = useState([]);
  const [editingUser, setEditingUser] = useState(null);
  const [editForm, setEditForm] = useState({
    username: '',
    name: '',
    tanggal_lahir: '',
    email: '',
    alamat: '',
    oldUsername: ''
  });
  const navigate = useNavigate();
  const formatDate = (dateString) => {
    if (!dateString) return '-';
    try {
      if (dateString instanceof Date) {
        return dateString.toLocaleDateString();
      }
      const date = new Date(dateString);
      return isNaN(date.getTime()) ? '-' : date.toLocaleDateString();
    } catch {
      return '-';
    }
  };
  useEffect(() => {
    fetchUsers();
  }, []);
  async function fetchUsers() {
    const data = await window.api.getAllUsers();
    setUsers(data);
  }
  async function handleDelete(username) {
    const confirmDelete = window.confirm(`Yakin ingin menghapus user ${username}?`);
    if (confirmDelete) {
      const result = await window.api.deleteUser(username);
      if (result.success) {
        alert("User berhasil dihapus.");
        fetchUsers();
      } else {
        alert("Gagal menghapus user: " + result.error);
      }
    }
  }
  function handleEditClick(user) {
    setEditingUser(user.username);
    setEditForm({
      username: user.username,
      name: user.NAME,
      tanggal_lahir: user.tanggal_lahir || '',
      email: user.email || '',
      alamat: user.alamat || '',
      oldUsername: user.username
    });
  }
  function handleInputChange(e) {
    const { name, value } = e.target;
    setEditForm(prev => ({ ...prev, [name]: value }));
  }
  async function handleSaveEdit() {
    const result = await window.api.updateUser(editForm);
    if (result.success) {
      alert("User berhasil diupdate.");
      setEditingUser(null);
      setEditForm({
        username: '',
        name: '',
        tanggal_lahir: '',
        email: '',
        alamat: '',
        oldUsername: ''
      });
      await fetchUsers();
    } else {
      alert("Gagal update user: " + result.error);
    }
  }
  function handleCancelEdit() {
    setEditingUser(null);
    setEditForm({
      username: '',
      name: '',
      tanggal_lahir: '',
      email: '',
      alamat: '',
      oldUsername: ''
    });
  }

  return (
    <div style={{ display: 'flex' }}>
      <nav style={{ width: '200px', padding: '20px', borderRight: '1px solid #ddd' }}>
        <h4>Admin Menu</h4>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li><button onClick={() => navigate('/admin')}>Home</button></li>
          <li><button onClick={() => navigate('/folders')}>Folder</button></li>
          <li><button onClick={() => navigate('/notes')}>Notes</button></li>
          <li><button onClick={() => navigate('/admin-grup')}>Group Folders</button></li>
          <li><button onClick={() => navigate('/admin-grup-note')}>Group Notes</button></li>
          <li><button onClick={() => navigate('/')}>Logout</button></li>
        </ul>
      </nav>
      <div style={{ flexGrow: 1, padding: '20px' }}>
        <header style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
          <h1>Data Seluruh Pengguna</h1>
        </header>
        {users.length === 0 ? (
          <p>Belum ada user terdaftar.</p>
        ) : (
          <>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={headerStyle}>No</th>
                  <th style={headerStyle}>Username</th>
                  <th style={headerStyle}>Nama</th>
                  <th style={headerStyle}>Tanggal Lahir</th>
                  <th style={headerStyle}>Email</th>
                  <th style={headerStyle}>Alamat</th>
                  <th style={headerStyle}>Aksi</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user, index) => (
                  <tr key={user.username}>
                    <td style={cellStyle}>{index + 1}</td>
                    <td style={cellStyle}>{user.username}</td>
                    <td style={cellStyle}>{user.NAME}</td>
                    <td style={cellStyle}>{user.tanggal_lahir ? formatDate(user.tanggal_lahir) : '-'}</td>
                    <td style={cellStyle}>{user.email || '-'}</td>
                    <td style={cellStyle}>{user.alamat || '-'}</td>
                    <td style={cellStyle}>
                      <button style={{ marginRight: 8 }} onClick={() => handleEditClick(user)}>Edit</button>
                      <button
                        style={{ marginRight: 8 }}
                        onClick={() => navigate('/detail-user', { state: user })}
                      >
                        View Detail
                      </button>
                      <button style={{backgroundColor: '#e74c3c', color: '#fff', border: 'none', padding: '5px 10px', cursor: 'pointer'}} onClick={() => handleDelete(user.username)}>
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {editingUser && (
              <div style={{
                marginTop: '20px',
                border: '1px solid #ccc',
                padding: '15px',
                borderRadius: '5px',
                backgroundColor: '#f9f9f9'
              }}>
                <h3>Edit User</h3>
                <div style={{ marginBottom: '10px' }}>
                  <label>Username:</label><br />
                  <input type="text" name="username" value={editForm.username} onChange={handleInputChange} style={{ width: '100%' }} />
                </div>
                <div style={{ marginBottom: '10px' }}>
                  <label>Nama:</label><br />
                  <input type="text" name="name" value={editForm.name} onChange={handleInputChange} style={{ width: '100%' }} />
                </div>
                <div style={{ marginBottom: '10px' }}>
                  <label>Tanggal Lahir:</label><br />
                  <input type="date" name="tanggal_lahir" value={editForm.tanggal_lahir} onChange={handleInputChange} style={{ width: '100%' }} />
                </div>
                <div style={{ marginBottom: '10px' }}>
                  <label>Email:</label><br />
                  <input type="email" name="email" value={editForm.email} onChange={handleInputChange} style={{ width: '100%' }} />
                </div>
                <div style={{ marginBottom: '10px' }}>
                  <label>Alamat:</label><br />
                  <textarea name="alamat" value={editForm.alamat} onChange={handleInputChange} style={{ width: '100%' }} rows={3}></textarea>
                </div>
                <div>
                  <button onClick={handleSaveEdit} style={{ marginRight: '10px' }}>Save Edit</button>
                  <button onClick={handleCancelEdit}>Cancel</button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

const headerStyle = {
  border: '1px solid #ccc',
  padding: '8px',
  textAlign: 'center',
  backgroundColor: '#f0f0f0',
};

const cellStyle = {
  border: '1px solid #ccc',
  padding: '8px',
  textAlign: 'center',
};