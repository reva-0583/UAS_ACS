import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
export default function AddMember() {
  const [groups, setGroups] = useState([])
  const [selectedGroup, setSelectedGroup] = useState('')
  const [usernameInput, setUsernameInput] = useState('')
  const navigate = useNavigate()
  const currentUser = localStorage.getItem('username')
  useEffect(() => {
    fetchGroupList()
  }, [])
  async function fetchGroupList() {
    try {
      const result = await window.api.getGroupFoldersByUser(currentUser)
      setGroups(result)
    } catch (err) {
      console.error('Gagal ambil grup:', err)
    }
  }
  async function handleSubmit() {
    if (!usernameInput.trim() || !selectedGroup) {
      alert('Semua field harus diisi.')
      return
    }
    try {
      const userCheck = await window.api.checkUsername(usernameInput)
      if (!userCheck.exists) {
        alert('Username tidak ditemukan.')
        return
      }
      const result = await window.api.addMemberToGroup({
        id_group_folder: selectedGroup,
        username: usernameInput
      })
      if (result.success) {
        alert('Member berhasil ditambahkan ke grup!')
        setUsernameInput('')
      } else {
        alert('Gagal menambahkan member: ' + result.error)
      }
    } catch (err) {
      console.error(err)
      alert('Terjadi kesalahan.')
    }
  }
  return (
    <div style={{ padding: 20 }}>
      <h2>Tambah Member ke Grup</h2>
      <div style={{ marginBottom: 10 }}>
        <label>Pilih Grup:</label><br />
        <select value={selectedGroup} onChange={e => setSelectedGroup(e.target.value)} style={{ padding: 8, width: 300 }}>
          <option value="">-- Pilih Grup --</option>
          {groups.map(group => (
            <option key={group.id_group_folder} value={group.id_group_folder}>
              {group.judul}
            </option>
          ))}
        </select>
      </div>
      <div style={{ marginBottom: 10 }}>
        <label>Username Member:</label><br />
        <input
          type="text"
          value={usernameInput}
          onChange={e => setUsernameInput(e.target.value)}
          style={{ padding: 8, width: 300 }}
        />
      </div>
      <button onClick={handleSubmit} style={{ marginRight: 10, padding: '5px 10px' }}>Submit</button>
      <button onClick={() => navigate('/grup')} style={{ padding: '5px 10px' }}>Back</button>
    </div>
  )
}