import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
export default function FolderPage() {
  const [folders, setFolders] = useState([]);
  const [editingFolder, setEditingFolder] = useState(null);
  const [editForm, setEditForm] = useState({id_folder: '', judul: '', username: '',});
  const navigate = useNavigate();
  useEffect(() => {
    fetchFolders();
  }, []);
  async function fetchFolders() {
    try {
      const data = await window.api.getAllFolders();
      setFolders(data);
    } catch (error) {
      console.error('Gagal fetch folders:', error);
    }
  }
  function handleEditClick(folder) {
    setEditingFolder(folder.id_folder);
    setEditForm({ ...folder });
  }
  function handleInputChange(e) {
    const { name, value } = e.target;
    setEditForm(prev => ({ ...prev, [name]: value }));
  }
  async function handleSaveEdit() {
    try {
      const result = await window.api.updateFolder(editForm);
      if (result.success) {
        alert('Folder berhasil diupdate.');
        setEditingFolder(null);
        setEditForm({ id_folder: '', judul: '', username: '' });
        fetchFolders();
      } else {
        alert('Gagal update folder: ' + result.error);
      }
    } catch (error) {
      alert('Terjadi error saat update folder.');
    }
  }
  async function handleDelete(id_folder) {
    const confirmDelete = window.confirm(`Yakin ingin menghapus folder dengan ID ${id_folder}?`);
    if (confirmDelete) {
      try {
        const result = await window.api.deleteFolder(id_folder);
        if (result.success) {
          alert('Folder berhasil dihapus.');
          fetchFolders();
        } else {
          alert('Gagal menghapus folder: ' + result.error);
        }
      } catch (error) {
        alert('Terjadi error saat menghapus folder.');
      }
    }
  }
  function handleCancelEdit() {
    setEditingFolder(null);
    setEditForm({ id_folder: '', judul: '', username: '' });
  }
  return (
    <div style={{ display: 'flex' }}>
      <nav style={{ width: '200px', padding: '20px', borderRight: '1px solid #ddd' }}>
        <h4>Admin Menu</h4>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li><button onClick={() => navigate('/admin')}>Home</button></li>
          <li><button onClick={() => navigate('/')}>Logout</button></li>
        </ul>
      </nav>
      <div style={{ flexGrow: 1, padding: '20px' }}>
        <header style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
          <h1>Data Folder</h1>
        </header>
        {folders.length === 0 ? (
          <p>Belum ada folder tersedia.</p>
        ) : (
          <>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={headerStyle}>No</th>
                  <th style={headerStyle}>ID Folder</th>
                  <th style={headerStyle}>Judul</th>
                  <th style={headerStyle}>Username</th>
                  <th style={headerStyle}>Aksi</th>
                </tr>
              </thead>
              <tbody>
                {folders.map((folder, index) => (
                  <tr key={folder.id_folder}>
                    <td style={cellStyle}>{index + 1}</td>
                    <td style={cellStyle}>{folder.id_folder}</td>
                    <td style={cellStyle}>{folder.judul}</td>
                    <td style={cellStyle}>{folder.username}</td>
                    <td style={cellStyle}>
                      <button style={{ marginRight: 8 }} onClick={() => handleEditClick(folder)}>Edit</button>
                      <button style={{ marginRight: 8 }} onClick={() => navigate('/detail-folder', { state: folder })}>View Details</button>
                      <button style={{ backgroundColor: '#e74c3c', color: '#fff', border: 'none', padding: '5px 10px', cursor: 'pointer' }} onClick={() => handleDelete(folder.id_folder)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {editingFolder && (
              <div style={{marginTop: '20px', border: '1px solid #ccc', padding: '15px', borderRadius: '5px', backgroundColor: '#f9f9f9'}}>
                <h3>Edit Folder</h3>
                <div style={{ marginBottom: '10px' }}>
                  <label>Judul:</label><br />
                  <input type="text" name="judul" value={editForm.judul} onChange={handleInputChange} style={{ width: '100%' }} />
                </div>
                <div style={{ marginBottom: '10px' }}>
                  <label>Username:</label><br />
                  <input type="text" name="username" value={editForm.username} readOnly style={{ width: '100%', backgroundColor: '#eee', cursor: 'not-allowed' }}/>
                </div>
                <div>
                  <button onClick={handleSaveEdit} style={{ marginRight: '10px' }}>Save Edit</button>
                  <button onClick={handleCancelEdit}>Cancel</button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
const headerStyle = {border: '1px solid #ccc', padding: '8px', textAlign: 'center', backgroundColor: '#f0f0f0',};
const cellStyle = {border: '1px solid #ccc', padding: '8px', textAlign: 'center',};