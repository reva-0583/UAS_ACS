import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
export default function ViewFolder() {
  const [folders, setFolders] = useState([])
  const navigate = useNavigate()
  const username = localStorage.getItem('username') || ''
  useEffect(() => {
    if (!username) {
      navigate('/login')
      return
    }
    window.api.viewFolder(username).then((data) => {
      setFolders(data)
    })
  }, [username, navigate])
  return (
    <div style={{ padding: 20 }}>
      <h2>Folder Pribadi Anda</h2>
      {folders.length > 0 ? (
        <ul>
          {folders.map((folder) => (
            <li key={folder.id_folder}><Link to={`/folder-detail/${folder.id_folder}`}>{folder.judul}</Link></li>
          ))}
        </ul>
      ) : (
        <p>Anda belum membuat folder.</p>
      )}
      <br />
      <button style={{ padding: '5px 10px', border: '1px solid #ccc', background: 'white', cursor: 'pointer', marginRight: 10 }} onClick={() => navigate('/addFolder')}>Add Folder</button>
      <button style={{ padding: '5px 10px', border: '1px solid #ccc', background: 'white', cursor: 'pointer' }} onClick={() => navigate('/dashboard')}>Back</button>
    </div>
  )
}