import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
export default function AddGrupNote() {
  const navigate = useNavigate();
  const location = useLocation();
  const group = location.state;
  const [judul, setJudul] = useState('');
  const [catatan, setCatatan] = useState('');
  useEffect(() => {
    if (!group || !group.id_group_folder) {
      alert("Group folder tidak ditemukan");
      navigate('/grup');
    }
  }, [group, navigate]);
  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!judul || !catatan) {
        alert('Judul dan Catatan tidak boleh kosong!')
        return
    }
    const username = localStorage.getItem('username')
    if (!username) {
        alert('User belum login')
        return
    }
    try {
        const result = await window.api.addGroupNote({
        id_group_folder: group.id_group_folder,
        judul,
        catatan,
        username
        })
        if (result.success) {
          const mentionedUsernames = catatan.match(/@(\w+)/g)?.map(m => m.substring(1)) || []
          for (const username_mentioned of mentionedUsernames) {
            await window.api.addMention({
              id_group_note: result.id_group_note,
              username_mentioned
            })
          }
          alert('Catatan berhasil ditambahkan')
          navigate(`/grup-detail/${group.id_group_folder}`)
        } else {
          alert('Gagal menambahkan catatan: ' + result.error)
        }
    } catch (error) {
        alert('Terjadi error saat menambahkan catatan')
    }
  }
  return (
    <div style={{ padding: '20px' }}>
      <button onClick={() => navigate(`/grup-detail/${group.id_group_folder}`)}>Back</button>
      <h2>Tambah Catatan Grup</h2>
      <form onSubmit={handleSubmit}>
        <label>Judul:</label><br />
        <input type="text" value={judul} onChange={e => setJudul(e.target.value)} required /><br /><br />
        <label>Catatan:</label><br />
        <textarea rows="4" value={catatan} onChange={e => setCatatan(e.target.value)} required></textarea><br /><br />
        <button type="submit">Simpan Catatan</button>
      </form>
    </div>
  );
}