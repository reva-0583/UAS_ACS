import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
const Detail = () => {
  const { judul } = useParams();
  const navigate = useNavigate();
  const [note, setNote] = useState(null);
  const [catatan, setCatatan] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [publicNotes, setPublicNotes] = useState([]);
  useEffect(() => {
    if (!judul) {
      console.error('Judul tidak ditemukan di URL');
      return;
    }
    const loadData = async () => {
      try {
        const noteData = await window.api.getNoteDetail(judul);
        if (!noteData) {
          console.error('Catatan tidak ditemukan');
          navigate('/dashboard');
          return;
        }
        setNote(noteData);
        setCatatan(noteData.catatan);
        
        const publicNotesData = await window.api.getPublicTitles();
        setPublicNotes(publicNotesData);
      } catch (error) {
        console.error('Gagal memuat data:', error);
      }
    };
    loadData();
  }, [judul, navigate]);
  const handleSave = async (e) => {
    e.preventDefault();
    try {
      await window.api.updateNote({ judul, catatan });
      setIsEditing(false);
      const updatedNote = await window.api.getNoteDetail(judul);
      setNote(updatedNote);
    } catch (error) {
      console.error('Gagal menyimpan:', error);
    }
  };
   const handleDelete = async () => {
    if (window.confirm('Apakah Anda yakin ingin menghapus catatan ini?')) {
      try {
        await window.api.deleteNote(judul);
        navigate('/dashboard');
      } catch (error) {
        console.error('Gagal menghapus catatan:', error);
      }
    }
  };
  if (!note) {
    return <div>Loading...</div>;
  }
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', margin: 0, padding: 0, display: 'flex' }}>
      <nav style={{width: '208px', backgroundColor: 'rgb(251, 251, 251)', padding: '20px', height: '100vh', position: 'fixed', top: 0, left: 0, borderRight: '2px solid rgba(128, 128, 128, 0.3)'}}>
        <h4>Public Notes</h4>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {publicNotes.map((note, index) => (
            <li key={index}>
              <a href={`/view-detail?judul=${note.judul}`} style={{ textDecoration: 'none', color: 'black' }}>
                {note.judul}
              </a>
            </li>
          ))}
        </ul>
        <h4>My Notes</h4>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li><a href="#" style={{ textDecoration: 'none', color: 'black' }}>Folder Pribadi</a></li>
          <li><a href="#" style={{ textDecoration: 'none', color: 'black' }}>Catatan Kuliah</a></li>
          <li><a href="#" style={{ textDecoration: 'none', color: 'black' }}>Proyek Kerja</a></li>
          <li><a href="#" style={{ textDecoration: 'none', color: 'black' }}>Jurnal Harian</a></li>
        </ul>
      </nav>
      <div style={{ flexGrow: 1, marginLeft: '250px', width: 'calc(100% - 250px)' }}>
        <div style={{position: 'fixed', top: 0, left: '250px', right: 0, width: 'calc(100% - 250px)', padding: '10px', backgroundColor: 'rgb(242, 242, 242)', borderBottom: '1px solid #ddd', display: 'flex', justifyContent: 'space-between', alignItems: 'center', zIndex: 1000}}>
          <h1 style={{ margin: 0 }}>Catat-Catat</h1>
          <div>
            <button style={{ marginLeft: '5px', padding: '5px 10px', border: '1px solid #ccc', background: 'white', cursor: 'pointer' }}>
              <a href="/dashboard" style={{ textDecoration: 'none', color: 'black' }}>Home</a>
            </button>
            <button style={{ marginLeft: '5px', padding: '5px 10px', border: '1px solid #ccc', background: 'white', cursor: 'pointer' }}>
              <a href="/view-folder" style={{ textDecoration: 'none', color: 'black' }}>Manage Group</a>
            </button>
            <button style={{ marginLeft: '5px', padding: '5px 10px', border: '1px solid #ccc', background: 'white', cursor: 'pointer' }}>
              <a href="/add-folder" style={{ textDecoration: 'none', color: 'black' }}>Add Folder</a>
            </button>
            <button style={{ marginLeft: '5px', padding: '5px 10px', border: '1px solid #ccc', background: 'white', cursor: 'pointer', marginRight: '15px' }}>
              <a href="/logout" style={{ textDecoration: 'none', color: 'black' }}>Logout</a>
            </button>
          </div>
        </div>
        <main style={{ padding: '20px', marginTop: '60px' }}>
          <button onClick={() => navigate('/dashboard')} style={{ padding: '10px 20px', color: 'black', border: 'none', cursor: 'pointer', marginRight: '10px' }}>
            Back
          </button>
          <button type="button" onClick={handleDelete} style={{ padding: '10px 20px', color: 'white', border: 'none', cursor: 'pointer', backgroundColor: 'red' }}>
            Delete
          </button>
          <br /><br />
          <h2 style={{ margin: 0, textAlign: 'left' }}>Detail Catatan</h2>
          <br />
          <button type="button" onClick={() => setIsEditing(true)} style={{ padding: '10px 20px', color: 'black', border: 'none', cursor: 'pointer' }}>
            Edit
          </button>
          <br /><br />
          <div style={{ border: '1px solid #ddd', padding: '20px', background: 'white', textAlign: 'left' }}>
            <h3 style={{ margin: 0, fontSize: '24px', marginBottom: '20px' }}>{note.judul}</h3>
            <form onSubmit={handleSave}>
              <textarea id="catatanText" value={catatan} onChange={(e) => setCatatan(e.target.value)} rows="10" style={{ width: '100%', fontSize: '16px' }} disabled={!isEditing}/>
              <br /><br />
              {isEditing && (
                <button type="submit" style={{ padding: '10px 20px', color: 'black', border: 'none', cursor: 'pointer' }}>
                  Save
                </button>
              )}
            </form>
          </div>
        </main>
      </div>
    </div>
  );
};
export default Detail;