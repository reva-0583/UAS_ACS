import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()
  const handleLogin = async (e) => {
    e.preventDefault()
    const adminResult = await window.api.adminLogin({ username, password })
    if (adminResult.success) {
      localStorage.setItem('admin', adminResult.admin.username)
      navigate('/admin')
      return
    }
    const userResult = await window.api.login({ username, password })
    if (userResult.success) {
      localStorage.setItem('username', userResult.user.username)
      navigate('/dashboard')
    } else {
      setError('Username atau password salah.')
    }
  }
  return (
    <div style={{ maxWidth: '400px', margin: '50px auto', padding: '20px', border: '1px solid #ccc' }}>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <div>
          <label>Username:</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            style={{ width: '100%', padding: '8px', margin: '8px 0' }}
          />
        </div>
        <div>
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            style={{ width: '100%', padding: '8px', margin: '8px 0' }}
          />
        </div>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <button type="submit" style={{ padding: '10px 15px', cursor: 'pointer' }}>
          Login
        </button>
      </form>
    </div>
  )
}
export default Login