import React, { useEffect, useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
export default function GrupPage() {
  const [grupFolders, setGrupFolders] = useState([])
  const [mentionCounts, setMentionCounts] = useState([])
  const navigate = useNavigate()
  const username = localStorage.getItem('username') || ''
  useEffect(() => {
    if (!username) {
      navigate('/login')
      return
    }
    window.api.getGroupFolders(username).then((data) => {
      setGrupFolders(data)
    })
    window.api.getMentionCountsByFolder(username).then((data) => {
      setMentionCounts(data)
    })
  }, [username, navigate])
  const getMentionCount = (id_folder) => {
    const data = mentionCounts.find(item => item.id_group_folder === id_folder)
    return data ? data.jumlah : 0
  }
  return (
    <div style={{ padding: 20 }}>
      <h2>Folder Grup Anda</h2>
      {grupFolders.length > 0 ? (
        <ul>
          {grupFolders.map((folder) => {
            const mentionCount = getMentionCount(folder.id_group_folder)
            return (
              <li key={folder.id_group_folder}>
                <Link to={`/grup-detail/${folder.id_group_folder}`}>
                  {folder.judul}
                  {mentionCount > 0 && (
                    <span style={{display: 'inline-block', marginLeft: '8px', minWidth: '8px', height: '20px', padding: '0 6px', backgroundColor: 'red', color: 'white', borderRadius: '50px', textAlign: 'center', fontSize: '12px', fontWeight: 'bold', lineHeight: '20px',}}> {mentionCount}</span>
                    )}
                </Link>
              </li>
            )
          })}
        </ul>
      ) : (
        <p>Kamu belum tergabung grup.</p>
      )}
      <br />
      <button style={{padding: '5px 10px', border: '1px solid #ccc', background: 'white', cursor: 'pointer', marginRight: 10,}} onClick={() => navigate('/addGrup')}>Add Grup</button>
      <button style={{padding: '5px 10px', border: '1px solid #ccc', background: 'white', cursor: 'pointer',}} onClick={() => navigate('/addMember')}>Add Member</button>
      <br /><br />
      <button style={{padding: '5px 10px', border: '1px solid #ccc', background: 'white', cursor: 'pointer',}} onClick={() => navigate('/dashboard')}>Back</button>
    </div>
  )
}