import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
const GrupNoteDetail = () => {
  const { id_group_note, id_group_folder } = useParams();
  const navigate = useNavigate();
  const [note, setNote] = useState(null);
  const [catatan, setCatatan] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  useEffect(() => {
    const fetchNote = async () => {
      try {
        const result = await window.api.getGroupNoteDetail(parseInt(id_group_note));
        if (result) {
          setNote(result);
          setCatatan(result.catatan);
        } else {
          alert('Catatan tidak ditemukan');
          navigate(`/group-detail/${id_group_folder}`);
        }
      } catch (err) {
        alert('Gagal memuat detail catatan');
        navigate(`/group-detail/${id_group_folder}`);
      }
    };
    fetchNote();
  }, [id_group_note, id_group_folder, navigate]);
  const handleSave = async (e) => {
    e.preventDefault();
    try {
      await window.api.updateGroupNote({ id_group_note: parseInt(id_group_note), catatan });
      setIsEditing(false);
      const updatedNote = await window.api.getGroupNoteDetail(parseInt(id_group_note));
      setNote(updatedNote);
    } catch (error) {
      alert('Gagal menyimpan perubahan');
    }
  };
  const handleDelete = async () => {
    if (window.confirm('Apakah Anda yakin ingin menghapus catatan ini?')) {
      try {
        await window.api.deleteGroupNote(parseInt(id_group_note));
        navigate(`/group-detail/${id_group_folder}`);
      } catch (err) {
        alert('Gagal menghapus catatan');
      }
    }
  };
  if (!note) return <div>Loading...</div>;
  return (
    <div style={{ padding: '20px' }}>
      <button onClick={() => navigate(`/grup-detail/${id_group_folder}`)} style={{ marginRight: '10px' }}>
        Back
      </button>
      <button onClick={handleDelete} style={{ backgroundColor: 'red', color: 'white' }}>
        Delete
      </button>
      <br /><br />
      <h2>{note.judul}</h2>
      <form onSubmit={handleSave}>
        <textarea
          value={catatan}
          onChange={(e) => setCatatan(e.target.value)}
          rows="10"
          style={{ width: '100%' }}
          disabled={!isEditing}
        />
        <br />
        {!isEditing && (
          <button type="button" onClick={() => setIsEditing(true)}>Edit</button>
        )}
        {isEditing && (
          <button type="submit">Save</button>
        )}
      </form>
    </div>
  );
};
export default GrupNoteDetail;