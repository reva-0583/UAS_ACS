import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
export default function NotePage() {
  const [notes, setNotes] = useState([]);
  const [editingNote, setEditingNote] = useState(null);
  const [editForm, setEditForm] = useState({
    id_catatan: '',
    id_folder: '',
    judul: '',
    catatan: '',
    akses: ''
  });
  const navigate = useNavigate();
  useEffect(() => {
    fetchNotes();
  }, []);
  async function fetchNotes() {
    try {
      const data = await window.api.getAllNotes();
      setNotes(data);
    } catch (error) {
      console.error('Gagal fetch notes:', error);
    }
  }
  function handleEditClick(note) {
    setEditingNote(note.id_catatan);
    setEditForm({ ...note });
  }
  function handleInputChange(e) {
    const { name, value } = e.target;
    setEditForm(prev => ({ ...prev, [name]: value }));
  }
  async function handleSaveEdit() {
    try {
      const result = await window.api.editNote(editForm);
      if (result.success) {
        alert('Catatan berhasil diupdate.');
        setEditingNote(null);
        setEditForm({ id_catatan: '', id_folder: '', judul: '', catatan: '', akses: '' });
        fetchNotes();
      } else {
        alert('Gagal update catatan: ' + result.error);
      }
    } catch (error) {
      alert('Terjadi error saat update catatan.');
    }
  }
  async function handleDelete(id_catatan) {
    const confirmDelete = window.confirm(`Yakin ingin menghapus catatan dengan ID ${id_catatan}?`);
    if (confirmDelete) {
      try {
        const result = await window.api.removeNote(id_catatan);
        if (result.success) {
          alert('Catatan berhasil dihapus.');
          fetchNotes();
        } else {
          alert('Gagal menghapus catatan: ' + result.error);
        }
      } catch (error) {
        alert('Terjadi error saat menghapus catatan.');
      }
    }
  }
  function handleCancelEdit() {
    setEditingNote(null);
    setEditForm({ id_catatan: '', id_folder: '', judul: '', catatan: '', akses: '' });
  }
  return (
    <div style={{ display: 'flex' }}>
      <nav style={{ width: '200px', padding: '20px', borderRight: '1px solid #ddd' }}>
        <h4>Admin Menu</h4>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li><button onClick={() => navigate('/admin')}>Home</button></li>
          <li><button onClick={() => navigate('/')}>Logout</button></li>
        </ul>
      </nav>
      <div style={{ flexGrow: 1, padding: '20px' }}>
        <header style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
          <h1>Data Catatan</h1>
        </header>
        {notes.length === 0 ? (
          <p>Belum ada catatan tersedia.</p>
        ) : (
          <>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={headerStyle}>No</th>
                  <th style={headerStyle}>ID</th>
                  <th style={headerStyle}>ID Folder</th>
                  <th style={headerStyle}>Judul</th>
                  <th style={headerStyle}>Catatan</th>
                  <th style={headerStyle}>Akses</th>
                  <th style={headerStyle}>Tanggal</th>
                  <th style={headerStyle}>Aksi</th>
                </tr>
              </thead>
              <tbody>
                {notes.map((note, index) => (
                  <tr key={note.id_catatan}>
                    <td style={cellStyle}>{index + 1}</td>
                    <td style={cellStyle}>{note.id_catatan}</td>
                    <td style={cellStyle}>{note.id_folder}</td>
                    <td style={cellStyle}>{note.judul}</td>
                    <td style={cellStyle}>{note.catatan}</td>
                    <td style={cellStyle}>{note.akses}</td>
                    <td style={cellStyle}>{new Date(note.tanggal_ditambahkan).toLocaleString()}</td>
                    <td style={cellStyle}>
                      <button style={{ marginRight: 8 }} onClick={() => handleEditClick(note)}>Edit</button>
                      <button style={{ marginRight: 8 }} onClick={() => navigate('/note-detail', { state: note })}>View Detail</button>
                      <button style={{ backgroundColor: '#e74c3c', color: '#fff', border: 'none', padding: '5px 10px', cursor: 'pointer' }} onClick={() => handleDelete(note.id_catatan)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {editingNote && (
              <div style={{ marginTop: '20px', border: '1px solid #ccc', padding: '15px', borderRadius: '5px', backgroundColor: '#f9f9f9' }}>
                <h3>Edit Catatan</h3>
                <div style={{ marginBottom: '10px' }}>
                  <label>Judul:</label><br />
                  <input type="text" name="judul" value={editForm.judul} onChange={handleInputChange} style={{ width: '100%' }} />
                </div>
                <div style={{ marginBottom: '10px' }}>
                  <label>Catatan:</label><br />
                  <textarea name="catatan" value={editForm.catatan} onChange={handleInputChange} style={{ width: '100%' }} rows={4}></textarea>
                </div>
                <div style={{ marginBottom: '10px' }}>
                  <label>Akses:</label><br />
                  <select name="akses" value={editForm.akses} onChange={handleInputChange} style={{ width: '100%' }}>
                    <option value="public">Public</option>
                    <option value="private">Private</option>
                  </select>
                </div>
                <div style={{ marginBottom: '10px' }}>
                  <label>ID Folder:</label><br />
                  <input type="text" name="id_folder" value={editForm.id_folder} readOnly style={{ width: '100%', backgroundColor: '#eee', cursor: 'not-allowed' }} />
                </div>
                <div>
                  <button onClick={handleSaveEdit} style={{ marginRight: '10px' }}>Save Edit</button>
                  <button onClick={handleCancelEdit}>Cancel</button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
const headerStyle = { border: '1px solid #ccc', padding: '8px', textAlign: 'center', backgroundColor: '#f0f0f0' };
const cellStyle = { border: '1px solid #ccc', padding: '8px', textAlign: 'center' };