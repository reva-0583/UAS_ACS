import React, { useEffect, useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
export default function GrupDetail() {
  const { id_group_folder } = useParams();
  const navigate = useNavigate();
  const [notes, setNotes] = useState([]);
  const [mentionCounts, setMentionCounts] = useState([]);
  const username = localStorage.getItem('username') || '';
  useEffect(() => {
    async function fetchNotes() {
      if (!id_group_folder || !username) return;
      const [notesData, mentionData] = await Promise.all([
        window.api.getGroupNotes(Number(id_group_folder)),
        window.api.getMentionCountsByNote(username),
      ]);
      setNotes(notesData);
      setMentionCounts(mentionData);
    }
    fetchNotes();
  }, [id_group_folder, username]);
  const handleDelete = async (id_group_note) => {
    if (!confirm('Yakin ingin menghapus catatan ini?')) return;
    const result = await window.api.deleteGroupNote(id_group_note);
    if (result.success) {
        const updated = notes.filter((n) => n.id_group_note !== id_group_note);
        setNotes(updated);
    } else {
        alert('Gagal hapus note.');
    }
    };
  const getMentionCount = (id_group_note) => {
    const found = mentionCounts.find(item => item.id_group_note === id_group_note);
    return found ? found.jumlah : 0;
  };
  return (
    <div style={{ display: 'flex' }}>
      <nav style={{ width: '200px', padding: '20px', borderRight: '1px solid #ddd' }}>
        <h4>Public Notes</h4>
        <ul style={{ listStyle: 'none', padding: 0 }}></ul>
        <h4>My Notes</h4>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li><Link to="/grup">Grup Saya</Link></li>
        </ul>
      </nav>
      <div style={{ flexGrow: 1, padding: '20px' }}>
        <header style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
          <h1>Group Notes in Folder {id_group_folder}</h1>
          <div>
            <button onClick={() => navigate('/dashboard')}>Home</button>
            <button onClick={() => navigate('/grup')}>Manage Group</button>
            <button onClick={() => navigate('/addGrup')}>Add Group</button>
          </div>
        </header>
        <button onClick={() => navigate('/addGrupNote', { state: { id_group_folder } })} style={{ marginBottom: '10px' }}>Add Note</button>
        {notes.length === 0 ? (
          <p>Folder grup kosong.</p>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'center' }}>No</th>
                <th style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'left' }}>Judul Note</th>
                <th style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'center' }}>Tanggal</th>
                <th style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'center' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {notes.map((note, idx) => (
                <tr key={note.id_group_note || idx}>
                  <td style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'center' }}>{idx + 1}</td>
                  <td style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'left' }}>
                    {note.judul}
                    {getMentionCount(note.id_group_note) > 0 && (
                    <span style={{backgroundColor: 'red', color: 'white', borderRadius: '500px', padding: '2px 8px', marginLeft: '8px', fontSize: '12px', display: 'inline-block', minWidth: '5px', textAlign: 'center', lineHeight: '17px', fontWeight: 'bold',}}>{getMentionCount(note.id_group_note)}</span>
                    )}
                  </td>
                  <td style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'center' }}>
                    {new Date(note.tanggal_ditambahkan).toLocaleDateString()}
                  </td>
                  <td style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'center' }}>
                    <button style={{ marginRight: '5px', padding: '4px 8px' }} onClick={() => navigate(`/group-note-detail/${id_group_folder}/${note.id_group_note}`)}>View Detail</button>
                    <button style={{ padding: '4px 8px' }} onClick={() => handleDelete(note.id_group_note)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}